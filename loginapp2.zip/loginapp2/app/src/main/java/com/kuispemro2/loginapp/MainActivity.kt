package com.kuispemro2.loginapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString()
            val password = etPassword.text.toString()

            if (username.length == 0 || password.length == 0) {
                Toast.makeText(this, "Isi semua kolom dulu!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Login Berhasil untuk: " + username, Toast.LENGTH_SHORT).show()
            }
        }
    }
}